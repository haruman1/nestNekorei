export interface JwtPayload {
  userId: string;
  name: string;
  email: string;
}
