import { CreateCartItemDto } from './create-cart-item.dto';
import { UpdateCartItemDto } from './update-cart-item.dto';

export declare namespace CartDto {
  export { CreateCartItemDto };
  export { UpdateCartItemDto };
}
