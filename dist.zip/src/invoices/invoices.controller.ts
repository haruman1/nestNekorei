import { Controller } from '@nestjs/common';

@Controller('invoices')
export class InvoicesController {}
