import { CreateOrderDto } from './create-order.dto';
import { UpdateOrderStatusDto } from './update-order.dto';
export declare namespace OrdersDto {
  export { CreateOrderDto };
  export { UpdateOrderStatusDto };
}
