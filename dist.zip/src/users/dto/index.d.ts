import { CreateUserDto } from './create-user.dto';
import { UpdateUserDto } from './update-user.dto';

export declare namespace UsersDto {
  export { CreateUserDto };
  export { UpdateUserDto };
}
